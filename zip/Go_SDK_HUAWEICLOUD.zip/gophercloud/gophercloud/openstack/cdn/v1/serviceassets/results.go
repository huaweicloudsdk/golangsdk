package serviceassets

import "github.com/gophercloud/gophercloud"

// DeleteResult represents the result of a Delete operation.
type DeleteResult struct {
	gophercloud.ErrResult
}
