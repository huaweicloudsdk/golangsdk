// Package lbaas_v2 provides information and interaction with the Load Balancer
// as a Service v2 extension for the OpenStack Networking service.
package lbaas_v2
