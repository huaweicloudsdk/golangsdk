package imageutil

import (
	"encoding/json"
	"fmt"
	"strings"
	//"strings"

	"github.com/gophercloud/gophercloud"
	"github.com/gophercloud/gophercloud/openstack/imageservice/v2/images"
)

// CreateOptsBuilder allows extensions to add parameters to the Create request.
type CreateOptsBuilder interface {
	// Returns value that can be passed to json.Marshal
	ToImageCreateMap() (map[string]interface{}, error)
}

// CreateOpts represents options used to create an image.
type CreateByServerOpts struct {
	// Name is the name of the new image.
	Name string `json:"name" required:"true"`

	// Description of image.
	Description string `json:"description,omitempty"`

	// server id to be converse
	InstanceId string `json:"instance_id,omitempty"`

	// image label "key.value"
	Tags []string `json:"tags,omitempty"`
}

// CreateOpts represents options used to create an image.
type CreateByFileOpts struct {
	// Name is the name of the new image.
	Name string `json:"name" required:"true"`

	// Description of image.
	Description string `json:"description,omitempty"`

	//OBS桶中外部镜像文件地址。
	ImageUrl string `json:"image_url,omitempty"`

	//操作系统版本。
	OsVersion string `json:"os_version,omitempty"`

	//是否自动配置，取值为true或false。
	IsConfig bool `json:"is_config,omitempty"`

	//是否完成了初始化配置。取值为true或false。
	IsConfigInit bool `json:"is_config_init,omitempty"`

	//最小系统盘大小。
	MinDisk int `json:"min_disk,omitempty"`

	//创建加密镜像的用户主密钥
	CmkId string `json:"cmk_id,omitempty"`

	//image label "key.value"
	Tags []string `json:"tags,omitempty"`
}

// ToImageCreateMap assembles a request body based on the contents of
// a CreateOpts.
func (opts CreateByServerOpts) ToImageCreateMap() (map[string]interface{}, error) {
	b, err := gophercloud.BuildRequestBody(opts, "")
	if err != nil {
		return nil, err
	}

	return b, nil
}

func (opts CreateByFileOpts) ToImageCreateMap() (map[string]interface{}, error) {
	b, err := gophercloud.BuildRequestBody(opts, "")
	if err != nil {
		return nil, err
	}

	return b, nil
}

// Create implements create image request.
func CreateImageByServer(client *gophercloud.ServiceClient, opts CreateOptsBuilder) (string, gophercloud.ErrorMessage) {
	var r CreateResult
	var em gophercloud.ErrorMessage
	b, err := opts.ToImageCreateMap()
	if err != nil {
		TransErrorMessage(err, &em)
		return "", em
	}

	url := createURL(client)
	_, r.Err = client.Post(url, b, &r.Body, &gophercloud.RequestOpts{OkCodes: []int{200}})

	job, err := r.ExtractJob()
	if err != nil || job == nil {
		TransErrorMessage(err, &em)
		return "", em
	}

	return job.Id, em
}

// Create implements create image request.
func CreateImageByFile(client *gophercloud.ServiceClient, opts CreateOptsBuilder) (string, gophercloud.ErrorMessage) {
	var r CreateResult
	var em gophercloud.ErrorMessage
	b, err := opts.ToImageCreateMap()
	if err != nil {
		TransErrorMessage(err, &em)
		return "", em
	}

	url := createURL(client)
	_, r.Err = client.Post(url, b, &r.Body, &gophercloud.RequestOpts{OkCodes: []int{200}})

	job, err := r.ExtractJob()
	if err != nil || job == nil {
		TransErrorMessage(err, &em)
		return "", em
	}

	return job.Id, em
}

// Get job result.
func GetJobResult(client *gophercloud.ServiceClient, id string) (*JobResult, gophercloud.ErrorMessage) {
	var r JobExecResult
	var em gophercloud.ErrorMessage
	url := jobURL(client, id)

	//把v2替换成v1,并且拼接上projectId
	newStr := fmt.Sprintf("/v1/%s/", client.ProjectId)
	url2 := strings.Replace(url, "/v2/", newStr, 1)

	_, r.Err = client.Get(url2, &r.Body, nil)

	jr, err := r.ExtractJobResult()
	if err != nil {
		TransErrorMessage(err, &em)
	}
	return jr, em
}

// Get implements image get request.
func GetImageDetail(client *gophercloud.ServiceClient, id string) (image *images.Image, em gophercloud.ErrorMessage) {
	image, err := images.Get(client, id).Extract()
	if err != nil {
		TransErrorMessage(err, &em)
	}
	return image, em
}

// Delete implements image delete request.
func DeleteImage(client *gophercloud.ServiceClient, id string) (em gophercloud.ErrorMessage) {
	err := images.Delete(client, id).ExtractErr()
	if err != nil {
		TransErrorMessage(err, &em)
	}
	return em
}

func TransErrorMessage(err error, em *gophercloud.ErrorMessage) {
	errString := fmt.Sprintf("%v", err)
	isJson := json.Unmarshal([]byte(errString), &em)
	if isJson != nil {
		em.ErrCode = "UnknowCode"
		em.Message = errString
	}
}
