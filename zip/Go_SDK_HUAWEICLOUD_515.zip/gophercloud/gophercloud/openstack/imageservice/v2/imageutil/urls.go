package imageutil

import (
	//"net/url"

	"github.com/gophercloud/gophercloud"
)

// `listURL` is a pure function. `listURL(c)` is a URL for which a GET
// request will respond with a list of images in the service `c`.
func createURL(c *gophercloud.ServiceClient) string {
	return c.ServiceURL("cloudimages/action")
}

// `getURL(c,i)` is a URL for which a GET request will respond with
// information about the image identified by ID `i` in the service
// `c`.
func getURL(c *gophercloud.ServiceClient, imageID string) string {
	return c.ServiceURL("images", imageID)
}

func deleteURL(c *gophercloud.ServiceClient, imageID string) string {
	return c.ServiceURL("images", imageID)
}

func jobURL(c *gophercloud.ServiceClient, jobId string) string {
	return c.ServiceURL("jobs", jobId)
}
