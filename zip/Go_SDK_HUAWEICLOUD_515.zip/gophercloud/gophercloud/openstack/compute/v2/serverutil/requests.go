package serverutil

import (
	//"fmt"

	"github.com/gophercloud/gophercloud"
	"github.com/gophercloud/gophercloud/openstack"
	"github.com/gophercloud/gophercloud/openstack/compute/v2/extensions/bootfromvolume"
	"github.com/gophercloud/gophercloud/openstack/compute/v2/extensions/startstop"
	"github.com/gophercloud/gophercloud/openstack/compute/v2/servers"
	"github.com/gophercloud/gophercloud/openstack/networking/v2/networks"
)

func CreateServer(client *gophercloud.ServiceClient, opts bootfromvolume.CreateOptsExt) (*servers.Server, gophercloud.ErrorMessage) {
	var em gophercloud.ErrorMessage

	//检查networks资源
	b, err := IsNetworksAvail(client, opts)
	if err != nil {
		TransErrorMessage(err, &em)
		return nil, em
	}
	if !b {
		return nil, gophercloud.ErrorMessage{ErrCode: "Ecs.1525", Message: "Insufficient IP addresses on the network."}
	}

	//创建server
	if len(opts.BlockDevice) > 0 {
		server, err := bootfromvolume.Create(client, opts).Extract()
		if err != nil {
			TransErrorMessage(err, &em)
		}
		return server, em
	} else {
		server, err := servers.Create(client, opts.CreateOptsBuilder).Extract()
		if err != nil {
			TransErrorMessage(err, &em)
		}
		return server, em
	}
}

func GetServerDetail(client *gophercloud.ServiceClient, id string) (*servers.Server, gophercloud.ErrorMessage) {
	var em gophercloud.ErrorMessage
	server, err := servers.Get(client, id).Extract()
	if err != nil {
		TransErrorMessage(err, &em)
	}
	return server, em
}

func DeleteServer(client *gophercloud.ServiceClient, id string) gophercloud.ErrorMessage {
	var em gophercloud.ErrorMessage
	err := servers.Delete(client, id).ExtractErr()
	if err != nil {
		TransErrorMessage(err, &em)
	}
	return em
}

func RebootServer(client *gophercloud.ServiceClient, id string, rtype string) gophercloud.ErrorMessage {
	var em gophercloud.ErrorMessage
	var rebootMethod servers.RebootMethod

	if rtype == "SOFT" {
		rebootMethod = servers.SoftReboot
	} else {
		rebootMethod = servers.HardReboot
	}

	rebootOpts := &servers.RebootOpts{
		Type: rebootMethod,
	}
	err := servers.Reboot(client, id, rebootOpts).ExtractErr()
	if err != nil {
		TransErrorMessage(err, &em)
	}
	return em
}

func StartServer(client *gophercloud.ServiceClient, id string) gophercloud.ErrorMessage {
	var em gophercloud.ErrorMessage
	err := startstop.Start(client, id).ExtractErr()
	if err != nil {
		TransErrorMessage(err, &em)
	}
	return em
}

func StopServer(client *gophercloud.ServiceClient, id string) gophercloud.ErrorMessage {
	var em gophercloud.ErrorMessage
	err := startstop.Stop(client, id).ExtractErr()
	if err != nil {
		TransErrorMessage(err, &em)
	}
	return em
}

func IsNetworksAvail(client *gophercloud.ServiceClient, opts bootfromvolume.CreateOptsExt) (bool, error) {
	//创建network client
	networkClient, err := openstack.NewNetworkV2(client.ProviderClient, gophercloud.EndpointOpts{})
	if err != nil {
		return false, err
	}

	base, err := opts.CreateOptsBuilder.ToServerCreateMap()
	if err != nil {
		return false, err
	}
	serverMap := base["server"].(map[string]interface{})
	nws := serverMap["networks"].([]map[string]interface{})
	//fmt.Println(networks)

	//整理过的network,uuid和其数量
	sortedNetworks := make(map[string]int)
	for _, n := range nws {
		if v, ok := n["uuid"]; ok {
			uuid, _ := v.(string)
			if uuid != "" {
				if _, ok := sortedNetworks[uuid]; ok {
					sortedNetworks[uuid]++
				} else {
					sortedNetworks[uuid] = 1
				}
			}
		}
	}

	//fmt.Println("sortedNetworks:", sortedNetworks)

	for uuid, needIps := range sortedNetworks {
		ia, err := networks.GetNetworkIpAvailabilities(networkClient, uuid)
		if err != nil {
			return false, err
		}

		availIps := ia.NetworkIpAvail.TotalIps - ia.NetworkIpAvail.UsedIps
		//fmt.Println("availIps:", availIps)
		//fmt.Println("needIps:", needIps)
		if availIps < needIps {
			return false, nil
		}

		continue
	}

	return true, nil
}

/*
//判断资源是否已满，创建server前判断。
func CheckHostAvailable(client *gophercloud.ServiceClient) (bool, error) {
	//查询所有status为error的servers
	listOpts := servers.ListOpts{
		Status: "ERROR",
	}

	allPages, err := servers.List(client, listOpts).AllPages()
	if nil != err {
		return true, err
	}

	allServers, err := servers.ExtractServers(allPages)
	if nil != err {
		return true, err
	}

	if 0 == len(allServers) {
		return true, err
	}

	for _, s := range allServers {
		b := strings.Contains(s.Fault.Message, "There are not enough hosts available")
		if b {
			return false, err
		}
	}

	return true, err
}
*/
