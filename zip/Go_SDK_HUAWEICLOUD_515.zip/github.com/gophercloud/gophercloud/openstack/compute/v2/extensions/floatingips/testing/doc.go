// floatingips unit tests
package testing
